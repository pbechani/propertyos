# Database Schema Overview

## Core Tables

### Users

-   id
-   email
-   password_hash
-   role
-   created_at

### Organizations

-   id
-   name
-   type
-   created_at

### Agents

-   id
-   user_id
-   license_number
-   brokerage_id

### Properties

-   id
-   address
-   city
-   country
-   property_type
-   land_size
-   building_size

### Listings

-   id
-   property_id
-   agent_id
-   price
-   status
-   created_at

### Media

-   id
-   listing_id
-   media_type
-   url

### Offers

-   id
-   listing_id
-   buyer_id
-   offer_price
-   status

### Contracts

-   id
-   offer_id
-   signed_at

### Mortgages

-   id
-   buyer_id
-   bank_id
-   status

### Payments

-   id
-   transaction_type
-   amount
-   status

### Ownership Records

-   id
-   property_id
-   owner_id
-   transfer_date
