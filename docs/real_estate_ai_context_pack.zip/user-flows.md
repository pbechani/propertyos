# User Flows

## Buyer Flow

Search Property → View Property → Request Viewing → Submit Offer → Offer
Accepted → Apply for Mortgage → Conveyancing → Ownership Transfer

## Seller Flow

Register → Add Property → Assign Agent → Publish Listing → Receive
Offers → Accept Offer → Conveyancing → Receive Funds

## Agent Flow

Create Listing → Market Property → Schedule Viewings → Manage Offers →
Close Sale

## Conveyancer Flow

Open Transfer Case → Verify Title → Prepare Documents → Lodge with
Registry → Transfer Ownership
