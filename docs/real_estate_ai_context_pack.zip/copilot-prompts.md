# Copilot Prompt Guide

Use these prompts inside your code editor.

## Generate Backend Service

Prompt: "Create a NestJS microservice for managing property listings
with CRUD endpoints and PostgreSQL integration."

## Generate Database Schema

Prompt: "Generate a PostgreSQL schema for a real estate platform
including users, properties, listings, offers, and transactions."

## Generate React UI

Prompt: "Create a Next.js dashboard UI for real estate agents to manage
property listings and viewing appointments."

## Generate Offer Workflow

Prompt: "Implement an offer negotiation workflow including
counteroffers, acceptance, and digital contract signing."
