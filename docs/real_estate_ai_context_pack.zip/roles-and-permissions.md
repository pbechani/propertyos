# Roles & Permissions

## Buyer

Permissions: - search properties - schedule viewing - submit offer -
apply for mortgage

## Seller

Permissions: - manage property - receive offers - accept/reject offers

## Agent

Permissions: - create listings - manage viewings - negotiate deals

## Conveyancer

Permissions: - manage transfer cases - upload legal documents - submit
deed transfers

## Contractor

Permissions: - respond to project requests - submit quotes

## Admin

Permissions: - manage users - moderate listings - fraud monitoring
