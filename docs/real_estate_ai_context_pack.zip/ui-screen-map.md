# UI Screen Map

## Public Website

-   Home
-   Property Search
-   Property Details
-   Agent Profiles
-   Developer Projects

## Buyer Portal

-   Dashboard
-   Saved Properties
-   Viewing Requests
-   Offers Submitted
-   Mortgage Applications

## Seller Portal

-   Property Dashboard
-   Listing Management
-   Offers Received
-   Transaction Progress

## Agent Portal

-   Agent Dashboard
-   Listings Manager
-   Lead CRM
-   Viewing Calendar
-   Deals Pipeline

## Conveyancer Portal

-   Case Dashboard
-   Document Upload
-   Transfer Tracking

## Contractor Marketplace

-   Contractor Directory
-   Supplier Catalog
-   Quote Requests

## Admin Dashboard

-   User Management
-   Listing Moderation
-   Fraud Detection
-   Analytics
