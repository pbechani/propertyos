# API Specification

## Authentication

POST /api/auth/register POST /api/auth/login POST /api/auth/logout

## Users

GET /api/users GET /api/users/{id}

## Properties

GET /api/properties POST /api/properties GET /api/properties/{id}

## Listings

GET /api/listings POST /api/listings GET /api/listings/{id}

## Offers

POST /api/offers GET /api/offers/{id} POST /api/offers/{id}/accept POST
/api/offers/{id}/reject

## Viewings

POST /api/viewings GET /api/viewings/{id}

## Mortgages

POST /api/mortgages/apply GET /api/mortgages/{id}

## Conveyancing

POST /api/transfers/start GET /api/transfers/{id}

## Payments

POST /api/payments/deposit POST /api/payments/release
